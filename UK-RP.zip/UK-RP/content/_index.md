---
title: "UK-Corp Community"
date: 2018-09-09T00:00:00-00:00
copyright: "uk-rp.com"
description: "Comunidad nacida del servidor Unknown Roleplay creado para SA-MP"

menu:
    - {url: "https://discord.gg/Av6MDD9", name: "Discord"}
---
