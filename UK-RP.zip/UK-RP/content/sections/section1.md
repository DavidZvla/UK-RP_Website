---
title: "About"
weight: 2
---

## About UK-Corp

Comunidad nacidad de Unknown Roleplay, servidor creado para la plataforma SA-MP

En un lapso de 5 años hemos abierto 2 servidores que se han vuelto populares y han dado de que hablar en la comunidad SA-MP de habla española.

En la actualidad... nos convertimos en una comunidad de jugadores de Elite, con usuarios de toda America Latina siguiendo nuestros proyectos y pasandola bien.

No dejes de sintonizar nuestros nuevos proyectos a lanzar. UK-Corp ha vuelto

Buscanos en [Discord](https://discord.gg/Av6MDD9)
