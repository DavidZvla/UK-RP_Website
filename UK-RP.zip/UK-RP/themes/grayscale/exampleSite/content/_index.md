---
title: "Hugo Grayscale Theme"
date: 2018-09-09T00:00:00-00:00
copyright: "Your Website"
description: "A port of the Grayscale theme to Hugo"

menu:
    - {url: "https://startbootstrap.com/themes/grayscale/", name: "Original"}
---
