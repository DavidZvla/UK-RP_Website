---
title: "Links"
weight: 3
improvecontrast: true
---

## Download Grayscale

You can download Grayscale for free from the Github page.

{{< big-button text="Visit Download Page" href="https://github.com/runningstream/hugograyscale/" >}}
