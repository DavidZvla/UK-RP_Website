---
title: "Contact"
weight: 4
---

## Contact Start Bootstrap

Feel free to leave us a comment on the [Grayscale template Github page](https://github.com/runningstream/hugograyscale/) to give some feedback about this theme!

{{< socialhandles >}}
    {{< twitter user="stream_running" >}}
    {{< github user="runningstream" >}}
{{< /socialhandles >}}
